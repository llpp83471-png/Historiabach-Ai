# Historia AI — Fase 1

MVP gratuito para generar una propuesta editorial semanal de Shorts de Historia de 2.º de Bachillerato.

## Qué hace esta primera versión
- Mantiene un catálogo inicial de temas.
- Prioriza por relevancia curricular y una señal editorial manual.
- Genera `weekly_plan.md` y `weekly_plan.json`.
- Puede ejecutarse manualmente o cada lunes mediante GitHub Actions.

**Importante:** esta fase NO consulta todavía tendencias reales de YouTube ni Google Trends. No presenta su puntuación como volumen de búsquedas. La integración con YouTube requiere crear un proyecto de Google Cloud, habilitar YouTube Data API y configurar credenciales; eso queda pendiente de resolver el permiso de creación de proyectos.

## Ejecutar en local
Requiere Python 3.10+ y no necesita paquetes externos:

```bash
python src/topic_research.py --count 5
```

Los informes aparecen en `output/`.

## Activar en GitHub
1. Crea una cuenta en https://github.com/
2. Crea un repositorio llamado `historia-ai`.
3. Para usar GitHub-hosted Actions sin consumir minutos de un plan privado, puedes elegir repositorio **público**. Ten presente que el código será visible para cualquiera.
4. Sube el contenido de esta carpeta respetando la estructura.
5. Abre la pestaña **Actions** y habilita los workflows si GitHub lo solicita.
6. Entra en **Historia AI - plan editorial semanal** y pulsa **Run workflow** para probarlo.
7. Descarga el artefacto `historia-ai-plan-editorial` cuando termine.

El horario programado es lunes a las 15:15 UTC (16:15 en España peninsular durante el horario de invierno; 17:15 durante el horario de verano). GitHub puede retrasar la ejecución programada. En repositorios públicos, GitHub puede desactivar workflows programados si no hay actividad durante 60 días.

## Seguridad
- No subas contraseñas, claves API, tokens OAuth ni archivos `client_secret`.
- No configures credenciales de YouTube hasta que la integración OAuth esté implementada.
- No se publica ningún vídeo en esta fase.

## Próximas fases
2. Investigación real de vídeos y temas con YouTube Data API.
3. Guiones con verificación de fuentes.
4. Renderizado vertical con FFmpeg, voz y subtítulos.
5. Revisión humana y publicación privada/programada mediante OAuth.
